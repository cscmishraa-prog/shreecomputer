SHREE COMPUTER website

How to preview:
1. Extract this ZIP file.
2. Open index.html in Chrome or another browser.

Included:
- Responsive Hindi/English website
- Services section
- Phone link and WhatsApp contact links for 7319930207
- Editable source in index.html

Before publishing:
- Confirm the WhatsApp number is correct and registered on WhatsApp.
- Add the shop's real address, opening hours, and real photos if desired.
- Upload the contents to a web host to make it public on the internet.
